//
//  Transition.m
//  MyFaces
//
//  Created by Erik Wrenholt on 10/29/06.
//  Copyright 2006 Timestretch Software. All rights reserved.
//

#import "Transition.h"

#define FRAME_RATE 30.0f	// fps

@implementation Transition

-(id)init
{
	self = [super init];
	if (self) {
		delegate = nil;
		startImage = nil;
		endImage = nil;
		timer = nil;
	}
	return self;
}


-(void)setStartImage:(CIImage*)inImage
{
	if (startImage != inImage) {
		[startImage release];
		startImage = [inImage retain];
	}
}
-(void)setEndImage:(CIImage*)inImage
{
	if (endImage != inImage) {
		[endImage release];
		endImage = [inImage retain];
	}
}

- (void)setupTransition 
{
    CIVector  *extent;
    float      w,h;
	CGRect imageSize = [endImage extent];
    w      = imageSize.size.width;
    h      = imageSize.size.height;
 
    extent = [CIVector vectorWithX: 0  Y: 0  Z: w  W: h];
 //CICopyMachineTransition
 
    transition  = [CIFilter filterWithName: @"CIModTransition"];
    [transition setDefaults];
//    [transition setValue: extent
//                forKey: @"inputExtent"];
    [transition   retain];
 
}

-(void)newTransitionWithStartImage:(CIImage*)sImage endImage:(CIImage*)eImage duration:(float)inDuration
{
	[self setStartImage: sImage];
	[self setEndImage:eImage];
	duration = inDuration;
	
    startTime = [NSDate timeIntervalSinceReferenceDate];
	frameCount = 0;
	[self setupTransition];
    timer = [[NSTimer scheduledTimerWithTimeInterval: 1.0/FRAME_RATE  
                        target: self
                        selector: @selector(timerFired:)  
                        userInfo: nil 
                        repeats: YES] retain];

    [[NSRunLoop currentRunLoop] addTimer: timer  
                                forMode: NSDefaultRunLoopMode];
	
}

- (CIImage *)imageForTransition: (float)t
{
    CIFilter  *crop;
 
	[transition setValue: startImage  forKey: @"inputImage"];
	[transition setValue: endImage  forKey: @"inputTargetImage"];
 
    [transition setValue: [NSNumber numberWithFloat: t]
                forKey: @"inputTime"];

	CGRect imageSize = [endImage extent];
    crop = [CIFilter filterWithName: @"CICrop"
                    keysAndValues: @"inputImage", 
                            [transition valueForKey: @"outputImage"],
                    @"inputRectangle", [CIVector vectorWithX: 0  Y: 0
                                        Z: imageSize.size.width  
                                        W: imageSize.size.height], 
                    nil];

    return [crop valueForKey: @"outputImage"];
}

-(void)timerFired:(id)sender
{
	BOOL isDone = NO;
	double now = [NSDate timeIntervalSinceReferenceDate];
	frameCount++;
	float t = (now - startTime)/duration;

	if (t > 1.0) {
		if ([timer isValid]) {
			[timer invalidate];
		}
		isDone = YES;
	}

	[delegate updateTransitionWithImage:[self imageForTransition:t] isDone:isDone];
}
-(void)setDelegate:(id)sender
{
	delegate = sender;
}
-(void)stop
{
	if ([timer isValid])
		[timer invalidate];
}
-(BOOL)isDone
{
	return NO;
}
-(void)dealloc
{
	if ([timer isValid])
		[timer invalidate];
	[timer release];
	[startImage release];
	[endImage release];
	[transition release];
	[super dealloc];
}
@end
