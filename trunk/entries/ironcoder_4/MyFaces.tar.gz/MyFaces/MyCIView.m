//
//  MyCIView.m
//  MyFaces
//
//  Created by Erik Wrenholt on 10/27/06.
//  Copyright 2006 Timestretch Software. All rights reserved.
//

#import "MyCIView.h"
#import "RandomPic.h"
#import "Transition.h"

@implementation MyCIView


-(void)awakeFromNib
{
	switchPics = YES;
}
-(NSString*)randomPic
{
	int imageId = rand();
	NSString *url = [RandomPic myspacePicWithID:imageId:@"l"];
	NSLog(url);
	return url;
}

- (id) initWithFrame: (NSRect)frame
{
    if ((self = [super initWithFrame: frame])) {
		newImage = nil;
		oldImage = nil;
		cachedImage = nil;
		srand(time(0));
    }
    return (self);

}

-(void)setNewImage:(CIImage*)inImage
{
	if (newImage != inImage) {
		[newImage release];
		newImage = [inImage retain];
	}
}

-(void)setOldImage:(CIImage*)inImage
{
	if (oldImage != inImage) {
		[oldImage release];
		oldImage = [inImage retain];
	}
}
-(void)setCachedImage:(CIImage*)inImage
{
	if (cachedImage != inImage) {
		[cachedImage release];
		cachedImage = [inImage retain];
	}
}
- (void)timerFired: (id)sender
{
    [self setNeedsDisplay: YES];
}
-(CIImage*)getImage
{
	CIImage *myImage = nil;
	while (!myImage) {
		myImage = [CIImage imageWithContentsOfURL:[NSURL URLWithString:[self randomPic]]];
	}
	return myImage;
}

-(void)resetImage
{
	[self setOldImage:newImage];

	switchPics = NO;
    CIImage *tempImage = [self getImage];

	NSRect bounds = [self bounds];

	CGRect imageSize = [tempImage extent];
	[self setNewImage:[tempImage 
		imageByApplyingTransform:CGAffineTransformMakeScale(
			bounds.size.width / imageSize.size.width,bounds.size.height / imageSize.size.height)]];

	if (oldImage == nil) {
		[self setOldImage:newImage];
	}
	[transition stop];
	[transition autorelease];
	transition = nil;
	
	transition = [[Transition alloc] init];
	[transition newTransitionWithStartImage:oldImage endImage:newImage duration:2.0];
	[transition setDelegate:self];
}

-(void)updateTransitionWithImage:(CIImage*)image isDone:(BOOL)isDone
{
	[self setCachedImage:image];
	[self setNeedsDisplay:YES];
	if (isDone) {
		if (switchPics)
			[self resetImage];
	}
}

-(void)mouseDown:(NSEvent*)event
{
	[self resetImage];
}


-(void)drawRect:(NSRect)rect
{
	CIContext* context = [[NSGraphicsContext currentContext] CIContext];
	CGRect imageSize = [cachedImage extent];
	[context drawImage: cachedImage  
                         atPoint: imageSize.origin  
                         fromRect: imageSize];  

}

@end
