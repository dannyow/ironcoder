//
//  Transition.h
//  MyFaces
//
//  Created by Erik Wrenholt on 10/29/06.
//  Copyright 2006 Timestretch Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <QuartzCore/QuartzCore.h>

@interface NSObject (TransitionDelegate)

-(void)updateTransitionWithImage:(CIImage*)image isDone:(BOOL)isDone;

@end

@interface Transition : NSObject {
	id delegate;
	double startTime;
	int frameCount;
	float duration;
	CIFilter *transition;
	CIImage *startImage;
	CIImage *endImage;
	NSTimer *timer;
}

-(void)newTransitionWithStartImage:(CIImage*)sImage endImage:(CIImage*)eImage duration:(float)duration;
-(void)setDelegate:(id)sender;
-(void)stop;
@end
