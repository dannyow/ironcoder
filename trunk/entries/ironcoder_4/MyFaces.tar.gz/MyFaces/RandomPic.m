//
//  RandomPic.m
//  MyFaces
//
//  Created by Erik Wrenholt on 10/27/06.
//  Copyright 2006 Timestretch Software. All rights reserved.
//

#import "RandomPic.h"


@implementation RandomPic

// imageSize can be 'l', 'm', 's' (large, medium, small)

+(NSString*)myspacePicWithID:(long)myID:(NSString*)imageSize
{
	NSString *imageString = [NSString stringWithFormat:@"%d", myID];
	int len = [imageString length];
	NSString *serverId = [imageString substringFromIndex:len-3];
	
	NSString *dir1;
	if ([imageString length] == 5)
		dir1 = imageString;
	else {
		NSString *dirPart = [imageString substringToIndex:len-6];
		dir1 = [NSString stringWithFormat:@"%@%@", [@"" stringByPaddingToLength:5-[dirPart length] withString: @"0" startingAtIndex:0],dirPart];
	}
	NSString *dir2 = [NSString stringWithFormat:@"%c%c", 
		[imageString characterAtIndex:len-1], [imageString characterAtIndex:len-2]];
	NSString *dir3 = [NSString stringWithFormat:@"%c%c", 
		[imageString characterAtIndex:len-3], [imageString characterAtIndex:len-4]];
	
	return [NSString stringWithFormat:@"http://myspace-%@.vo.llnwd.net/%@/%@/%@/%@_%@.jpg",
		serverId,dir1,dir2,dir3,imageString,imageSize];
}

/*
From: http://www.jacobdehart.com/phpbits/viewmyspaceimages.php

function myspace_getimagepath($id, $size){
	$id = strval($id);
	$len = strlen($id);
	$serverid = substr($id,$len-3,3);
	
	$dir1 = str_pad( substr($id,0,$len-6) ,5,'0',STR_PAD_LEFT);
	
	$dir2 = trim($id{$len-1}.$id{$len-2});
	
	$dir3 = trim($id{$len-3}.$id{$len-4});
	
	$path = "http://myspace-{$serverid}.vo.llnwd.net/{$dir1}/{$dir2}/{$dir3}/{$id}_{$size}.jpg";
	return $path;
}
*/
@end
