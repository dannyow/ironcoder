//
//  main.m
//  MyFaces
//
//  Created by Erik Wrenholt on 9/30/06.
//  Copyright Timestretch Software 2006. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
