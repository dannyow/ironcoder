//
//  FullScreenWindow.h
//  MyFaces
//
//  Created by Erik Wrenholt on 10/27/06.
//  Copyright 2006 Timestretch Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface FullScreenWindow : NSWindow {

}

@end
