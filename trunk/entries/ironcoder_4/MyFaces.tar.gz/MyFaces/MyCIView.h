//
//  MyCIView.h
//  MyFaces
//
//  Created by Erik Wrenholt on 10/27/06.
//  Copyright 2006 Timestretch Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <QuartzCore/QuartzCore.h>

@class Transition;

@interface MyCIView : NSView {
    CIFilter *filter;
	CIImage *oldImage;
	CIImage *newImage;
	CIImage *cachedImage;
	Transition *transition;
	BOOL switchPics;
}
-(void)resetImage;

@end
