﻿MyFaces downloads random pictures from MySpace.

Click the mouse button to see another image.

By Erik Wrenholt
http://www.timestretch.com/