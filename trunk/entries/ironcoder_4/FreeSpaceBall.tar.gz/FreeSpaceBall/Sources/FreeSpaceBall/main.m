//
//  main.m
//  FreeSpaceBall
//
//  Created by Henry Skelton on 10/28/06.
//  Copyright Henry Skelton 2006. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
