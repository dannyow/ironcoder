//
//  main.m
//  NoTime
//
//  Created by Duncan Wilcox on 7/22/06.
//  Copyright Duncan Wilcox 2006. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
