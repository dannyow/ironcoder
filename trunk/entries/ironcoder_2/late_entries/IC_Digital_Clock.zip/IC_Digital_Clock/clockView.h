/* clockView */

#import <Cocoa/Cocoa.h>

@interface clockView : NSView
{
	NSTimer *timer;
}
@end
