//
//  main.m
//  IC_Digital_Clock
//
//  Created by Kitwana Akil on 7/23/06.
//  Copyright __MyCompanyName__ 2006. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
