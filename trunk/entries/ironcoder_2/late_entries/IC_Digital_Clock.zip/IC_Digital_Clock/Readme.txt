Iron Coder Submission:  IC_Digital Clock

Submitted by:  Kitwana D. Akil
				kakil@mac.com
				904-894-8954
				
About the app:

This is a simple clock app that was created using Quartz 2D.  The app displays the current time and date.  To run the app just compile and run.  


Special Thanks:

Thank you to Iron Coder!  This is the first app that I have ever created using Cocoa!  
