//
//  main.m
//  TimeLapse
//
//  Created by Andy Kim on 7/22/06.
//  Copyright Potion Factory 2006. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
