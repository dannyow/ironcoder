//
//  TLGradientView.h
//  TimeLapse
//
//  Created by Andy Kim on 7/23/06.
//  Copyright 2006 Potion Factory. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface TLGradientView : NSView {

}

@end
