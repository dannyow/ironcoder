//
//  main.m
//  MouseLapse
//
//  Created by 23 on 7/22/06.
//  Copyright 23 2006. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
