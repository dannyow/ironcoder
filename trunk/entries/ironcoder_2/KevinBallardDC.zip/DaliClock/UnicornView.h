//
//  UnicornView.h
//  DaliClock
//
//  Created by Kevin Ballard on 7/23/06.
//  Copyright 2006 Tildesoft. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface UnicornView : NSView {

}

@end
