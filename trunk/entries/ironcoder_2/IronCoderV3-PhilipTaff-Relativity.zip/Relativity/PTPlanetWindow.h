//
//  PTPlanetWindow.h
//  Relativity
//
//  Created by Philip on 7/23/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#define PLANET_SIZE 400


@interface PTPlanetWindow : NSWindow 
{

}

@end
