//
//  main.m
//  TopQuartz
//
//  Created by Chip Coons on 7/21/06.
//  Copyright GWSoftware 2006. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
