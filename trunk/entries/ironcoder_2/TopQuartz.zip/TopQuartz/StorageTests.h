//
//  StorageTests.h
//  TopQuartz
//
//  Created by Chip Coons on 7/22/06.
//  Copyright 2006 GWSoftware. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>
#import "Storage.h"

@interface StorageTests : SenTestCase {
	Storage *testStorage;
}

@end
