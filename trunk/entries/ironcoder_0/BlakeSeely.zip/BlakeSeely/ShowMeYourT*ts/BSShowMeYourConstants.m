//
//  ShowMeYourT*ts
//
//  Created by Blake Seely on 3/4/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import "BSShowMeYourConstants.h"


int kBeadsPerNecklace = 20;
int kMaxNecklaces = 100;
int kMaxPixelsBetweenBeads = 25;
int kPixelsPerBead = 16;
NSTimeInterval kThrowInterval = 2.0;
int kGravityAcceleration = 50;
