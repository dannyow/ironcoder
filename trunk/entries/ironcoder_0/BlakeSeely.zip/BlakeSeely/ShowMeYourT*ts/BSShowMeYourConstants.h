//
//  ShowMeYourT*ts
//
//  Created by Blake Seely on 3/4/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

extern int kBeadsPerNecklace;
extern int kMaxNecklaces;
extern int kMaxPixelsBetweenBeads;
extern int kPixelsPerBead;
extern NSTimeInterval kThrowInterval;
extern int kGravityAcceleration;
