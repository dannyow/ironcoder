/* BSBourbonStreetView */

#import <Cocoa/Cocoa.h>
#import "BSShowMeYourAppDelegate.h"

@interface BSBourbonStreetView : NSView
{
    IBOutlet BSShowMeYourAppDelegate *showMeYourAppController;
}
@end
