//
//  main.m
//  Conway's Game of Life Cereal
//
//  Created by Buckley on 3/30/07.
//  Copyright Michael Buckley 2007. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
