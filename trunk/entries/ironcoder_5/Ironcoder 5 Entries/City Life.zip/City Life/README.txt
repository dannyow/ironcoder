City Life

Description:
A group of people representing the events of your life build a city using the tools of your daily life as well.

Usage:
Just double click on CityLife.saver to install it. You need to have icons in your iPhoto Library (which needs to be at {HOME}/Pictures/iPhoto Library/) and applications in /Applications. Sorry for the load times, takes maybe 5 seconds on a Macbook Pro.

Use of API:
Obviously it's a screensaver so it uses the SS framework. Also uses OpenGL for the drawing and a little bit of ImageIO for loading textures.

License:
Copyright (c) 2007, Steven Canfield

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

