//
//  ICOpenGLView.m
//  Life Player
//
//  Created by Geoff Pado on 3/31/07.
//  Copyright 2007 A Clockwork Apple. All rights reserved.
//

#import "ICOpenGLView.h"


@implementation ICOpenGLView

- (BOOL)isOpaque
{
	return NO;
}

@end