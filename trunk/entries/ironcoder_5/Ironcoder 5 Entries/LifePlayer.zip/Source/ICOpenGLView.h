//
//  ICOpenGLView.h
//  Life Player
//
//  Created by Geoff Pado on 3/31/07.
//  Copyright 2007 A Clockwork Apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface ICOpenGLView : NSOpenGLView {

}

@end
