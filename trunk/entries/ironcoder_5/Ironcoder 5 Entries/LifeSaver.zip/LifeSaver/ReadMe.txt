READMEEEEEE!!!

This is "LifeSaver" by Jason Terhorst
It's a screensaver, and it's a game!

The object of the game is very simple - catch all of the LifeSavers. A hand will appear which represent your mouse cursor. Move the mouse, and catch the Lifesaver candies that appear from the top of the screen. Your score is written on the bottom left of the screen as "x/x", or read as "number of candies caught out of the total number of candies spawned".

Tech notes:
To keep the screensaver from getting out of control, the game resets after 100 lifesavers have been generated. The images are low-rez to keep this small.
To manually start the game, you'll need to set a screen corner to activate the screen saver. Simply clicking "Test" in the SystemPrefrences will not work well. You can also use a screen saver debugging tool that supports mouse movement events.
To exit the game, click the mouse or a key on the keyboard.

// This is another weird something from Jason Terhorst. Please check out my portfolio and more at http://www.jterhorst.com
Thanks!