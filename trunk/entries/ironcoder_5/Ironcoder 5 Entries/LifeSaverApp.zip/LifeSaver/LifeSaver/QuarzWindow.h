//
//  QuarzWindow.h
//  Sleeper
//
//  Created by Karsten Kusche on 31.03.07.
//  Copyright 2007 briksoftware.com. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "HiddenWindow.h"

@interface QuarzWindow : HiddenWindow {

}

@end
