//
//  main.m
//  LifeSaver
//
//  Created by Karsten Kusche on 31.03.07.
//  Copyright briksoftware.com 2007. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
