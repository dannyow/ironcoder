//
//  StatusItemExtension.h
//  LifeSaver
//
//  Created by Karsten Kusche on 01.04.07.
//  Copyright 2007 briksoftware.com. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface NSStatusItem (Hack)
- (NSRect)hackFrame;
@end

