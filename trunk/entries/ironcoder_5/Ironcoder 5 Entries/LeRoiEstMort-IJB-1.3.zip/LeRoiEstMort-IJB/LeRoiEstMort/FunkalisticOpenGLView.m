//
//  FunkalisticOpenGLView.m
//  LeRoiEstMort
//
//  Created by Ian J. Baird on 3/30/07.
//  Copyright 2007 Ian J. Baird. All rights reserved.
//

#import "FunkalisticOpenGLView.h"


@implementation FunkalisticOpenGLView

- (BOOL)isOpaque
{
    return NO;
}

@end
