/System/Library/Frameworks/Python.framework/Versions/Current/bin/python setup.py clean
/System/Library/Frameworks/Python.framework/Versions/Current/bin/python setup.py py2app
open dist/LifeSaver.saver
