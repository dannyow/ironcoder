//==============================================================================
// File:      GLUtilities.h
// Date:      4/1/07
// Author:		Dan Waylonis
// Copyright:	(C) 2007 nekotech SOFTWARE
// 
// Open GL utilities
//==============================================================================
#import <Cocoa/Cocoa.h>

void DrawGLRect(NSRect r, NSColor *color);
