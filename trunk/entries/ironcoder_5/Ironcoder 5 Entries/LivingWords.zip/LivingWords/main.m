//==============================================================================
// File:      main.m
// Date:      4/1/07
// Author:		Dan Waylonis
// Copyright:	(C) 2007 nekotech SOFTWARE
//==============================================================================
#import <Cocoa/Cocoa.h>

int main(int argc, const char *argv[]) {
  return NSApplicationMain(argc, (const char **)argv);
}
