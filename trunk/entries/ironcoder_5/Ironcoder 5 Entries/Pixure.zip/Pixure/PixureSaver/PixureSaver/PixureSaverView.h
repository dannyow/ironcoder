//
//  PixureSaverView.h
//  PixureSaver
//
//  Created by Joseph Wardell on 4/1/07.
//  Copyright (c) 2007, Old Jewel Software. All rights reserved.
//

#import <ScreenSaver/ScreenSaver.h>

@class PixureSystem;
@class ImageFileThumbnailCache;

@interface PixureSaverView : ScreenSaverView 
{
}
@end
