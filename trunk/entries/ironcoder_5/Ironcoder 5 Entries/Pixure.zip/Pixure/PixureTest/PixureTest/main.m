//
//  main.m
//  PixureTest
//
//  Created by Joseph Wardell on 3/30/07.
//  Copyright Old Jewel Software 2007. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
