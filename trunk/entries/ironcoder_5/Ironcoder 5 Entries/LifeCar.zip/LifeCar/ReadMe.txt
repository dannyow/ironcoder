Date:		3/31/07
Version:	1.0
Author:		Michael Bianco <software@mabwebdesign.com>, http://mabblog.com/

Uses Robbert Penners bounce equations... uses a quote from forest gump - that's about it. Hope you like it!