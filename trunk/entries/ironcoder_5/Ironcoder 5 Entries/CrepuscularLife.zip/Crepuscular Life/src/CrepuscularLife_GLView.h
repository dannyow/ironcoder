//
//  CrepuscularLife_GLView.h
//  Crepuscular Life
//
//  Created by Josh Freeman on 3/31/07.
//  Copyright 2007 Twilight Edge Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface CREPLIFE_GLView : NSOpenGLView 
{
}

@end
