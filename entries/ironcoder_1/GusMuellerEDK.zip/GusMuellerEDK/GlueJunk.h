//
//  Junk.h
//  iTunesXPlugIn
//
//  Created by August Mueller on 5/19/06.
//  Copyright 2006 Flying Meat Inc.. All rights reserved.
//

#import "iTunesVisualAPI.h"

void doSomething(void);

void LEVisualPluginHandler(OSType message,VisualPluginMessageInfo *messageInfo,void *refCon);