//
//  Junk.m
//  iTunesXPlugIn
//
//  Created by August Mueller on 5/19/06.
//  Copyright 2006 Flying Meat Inc.. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#import "GlueJunk.h"
#import "LEController.h"

void doSomething(void) {


    
}
