//
//  CPreviewer.h
//  AXURLTest
//
//  Created by Jonathan Wight on 01/28/2005.
//  Copyright 2005 Toxic Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface CPreviewer : NSObject {
}

- (NSView *)previewForURL:(NSURL *)inURL;

@end
