//
//  CCrossHairWindow.m
//  AXURLTest
//
//  Created by Jonathan Wight on 3/3/06.
//  Copyright 2006 Toxic Software. All rights reserved.
//

#import "CCrossHairWindow.h"

static CCrossHairWindow *gSharedWindow = NULL;

@implementation CCrossHairWindow

+ (CCrossHairWindow *)sharedWindow;
{
return(gSharedWindow);
}

- (id)initWithContentRect:(NSRect)contentRect styleMask:(unsigned int)aStyle backing:(NSBackingStoreType)bufferingType defer:(BOOL)flag
{
if (self = [super initWithContentRect:contentRect styleMask:NSBorderlessWindowMask backing:bufferingType defer:flag])
	{
	if (gSharedWindow == NULL)
		gSharedWindow = self;
	}
return(self);
}

// NSWindow
- (void)awakeFromNib
{
[super awakeFromNib];
[self setMovableByWindowBackground:YES];
[self setLevel:NSScreenSaverWindowLevel];
}

- (void)drawRect:(NSRect)inRect;
{
[NSGraphicsContext saveGraphicsState];
//
NSRect theBounds = { NSZeroPoint, [self frame].size };
NSBezierPath *thePath = NULL;
//
NSPoint theCenter = { .x = NSMidX(theBounds), .y = NSMidY(theBounds) };
NSRect theEye = { .origin = theCenter, .size = NSZeroSize };
theEye = NSInsetRect(theEye, -8, -8);
thePath = [NSBezierPath bezierPathWithOvalInRect:theBounds];
[thePath appendBezierPathWithOvalInRect:theEye];
[thePath setWindingRule:NSEvenOddWindingRule];
[thePath addClip];
//
thePath = [NSBezierPath bezierPathWithOvalInRect:NSInsetRect(theBounds, 20.0, 20.0f)];
[NSGraphicsContext saveGraphicsState];
[[NSGraphicsContext currentContext] setCompositingOperation:NSCompositeDestinationOver];
[[NSColor colorWithDeviceRed:1.0 green:0.0 blue:0.0 alpha:0.5] set];
[thePath fill];
[NSGraphicsContext restoreGraphicsState];
//
thePath = [NSBezierPath bezierPathWithOvalInRect:NSInsetRect(theBounds, 16.0f, 16.0f)];
[NSGraphicsContext saveGraphicsState];
[[NSGraphicsContext currentContext] setCompositingOperation:NSCompositeDestinationOver];
[[NSColor colorWithDeviceWhite:0.0 alpha:0.5] set];
[thePath setLineWidth:8.0f];
[thePath stroke];
[NSGraphicsContext restoreGraphicsState];
//
[NSGraphicsContext restoreGraphicsState];
}

- (NSPoint)point
{
NSRect theFrame = [self frame];
NSPoint thePoint = { .x = NSMidX(theFrame), .y = NSMidY(theFrame) };
return(thePoint);
}

@end
