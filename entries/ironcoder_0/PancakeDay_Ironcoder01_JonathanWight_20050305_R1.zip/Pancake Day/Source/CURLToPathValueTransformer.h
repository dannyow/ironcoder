//
//  CURLToPathValueTransformer.h
//  
//
//  Created by Jonathan Wight on 02/28/2006.
//  Copyright 2006 Toxic Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface CURLToPathValueTransformer : NSValueTransformer {

}

@end
