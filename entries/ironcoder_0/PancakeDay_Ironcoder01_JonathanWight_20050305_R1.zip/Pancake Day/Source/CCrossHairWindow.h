//
//  CCrossHairWindow.h
//  AXURLTest
//
//  Created by Jonathan Wight on 3/3/06.
//  Copyright 2006 Toxic Software. All rights reserved.
//

#import "CToxicTransparentShapedWindow.h"


@interface CCrossHairWindow : CToxicTransparentShapedWindow {
}

+ (CCrossHairWindow *)sharedWindow;

- (NSPoint)point;

@end
