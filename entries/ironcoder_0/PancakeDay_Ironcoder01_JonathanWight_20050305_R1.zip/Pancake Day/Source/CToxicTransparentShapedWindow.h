//
//  CToxicTransparentShapedWindow.h
//  Shelf Life
//
//  Created by Jonathan Wight on 09/13/2004.
//  Copyright 2004 Toxic Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>

/**
 * @class CTransparentShapedWindow
 * @discussion Provides an NSWindow subclass that is transparent and provides its own "drawRect:" method. Note that this class will replace its contentView with a special NSView.
 */
@interface CToxicTransparentShapedWindow : NSWindow {
}

- (Class)contentViewDefaultClass;

- (void)drawRect:(NSRect)inRect;

@end
