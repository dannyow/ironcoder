//
//  CImagePreviewer.h
//  Ironcoder
//
//  Created by Jonathan Wight on 03/05/2006.
//  Copyright 2006 Toxic Software. All rights reserved.
//

#import "CPreviewer.h"

@interface CImagePreviewer : CPreviewer {

}

- (NSView *)previewForURL:(NSURL *)inURL;

@end
