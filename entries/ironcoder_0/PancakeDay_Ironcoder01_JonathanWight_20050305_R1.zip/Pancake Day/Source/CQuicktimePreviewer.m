//
//  CQuicktimePreviewer.m
//  Ironcoder
//
//  Created by Jonathan Wight on 3/5/06.
//  Copyright 2006 Toxic Software. All rights reserved.
//

#import "CQuicktimePreviewer.h"

#import "CPreviewManager.h"

#import <QTKit/QTKit.h>

@implementation CQuicktimePreviewer

+ (void)initialize
{
[[CPreviewManager instance] registerPreviewer:[[[self alloc] init] autorelease] forType:@"public.movie"];
}

- (NSView *)previewForURL:(NSURL *)inURL
{
QTMovieView *theMovieView = [[[QTMovieView alloc] initWithFrame:NSMakeRect(0, 0, 256, 256)] autorelease];//

NSError *theError = NULL;
QTMovie *theMovie = [QTMovie movieWithURL:inURL error:&theError];
[theMovie gotoPosterTime];

[theMovieView setMovie:theMovie];

return(theMovieView);
}

@end
