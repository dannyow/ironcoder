//
//  NSScreen_Extensions.h
//  AXURLTest
//
//  Created by Jonathan Wight on 3/3/06.
//  Copyright (c) 2006 Toxic Software. All rights reserved.
//

#import <AppKit/AppKit.h>

/**
 * @category NSObject (NSScreen_Extensions)
 * @abstract TODO
 * @discussion TODO
 */
@interface NSScreen (NSScreen_Extensions)

+ (NSScreen *)screenContainingPoint:(NSPoint)inPoint;

@end
