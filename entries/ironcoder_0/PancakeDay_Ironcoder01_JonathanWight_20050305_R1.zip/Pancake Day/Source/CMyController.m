//
//  CMyController.m
//  AXURLTest
//
//  Created by Jonathan Wight on 01/26/2005.
//  Copyright 2005 Toxic Software. All rights reserved.
//

#import "CMyController.h"

#import "NSScreen_Extensions.h"
#import "CCrossHairWindow.h"
#import "CPointValueTransformer.h"
#import "CURLToPathValueTransformer.h"
#import "CImagePreviewer.h"
#import "CPreviewManager.h"
#import "CCrossHairWindow.h"
#import "CHTMLPreviewer.h"
#import "CPDFPreviewer.h"
#import "CQuicktimePreviewer.h"

@implementation CMyController

- (id)init
{
if ((self = [super init]) != NULL)
	{
	[CPointValueTransformer initialize];
	[CURLToPathValueTransformer initialize];
	}
return(self);
}

- (void)awakeFromNib
{
[CImagePreviewer initialize];
[CHTMLPreviewer initialize];
[CPDFPreviewer initialize];
[CQuicktimePreviewer initialize];

[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(windowDidMove:) name:NSWindowDidMoveNotification object:crossHairWindow];
}

#pragma mark -

- (NSPoint)focusPoint
{
return(focusPoint);
}

- (void)setFocusPoint:(NSPoint)inFocusPoint
{
if (NSEqualPoints(inFocusPoint, focusPoint) == NO)
	{
	focusPoint = inFocusPoint;

	NSScreen *theScreen = [NSScreen screenContainingPoint:focusPoint];
	if (theScreen != NULL)
		{
		AXUIElementRef theElement = NULL;
		AXError theError = AXUIElementCopyElementAtPosition(AXUIElementCreateSystemWide(), focusPoint.x, [theScreen frame].size.height - focusPoint.y, &theElement);
		//NSLog(@"%d %d", theError, theElement);

		CFTypeRef theValue = NULL;
		theError = AXUIElementCopyAttributeValue(theElement, CFSTR("AXURL"), &theValue);

		[self setUrl:(id)theValue];

		if (theValue != NULL)
			CFRelease(theValue);
		if (theElement)
			CFRelease(theElement);
			
		}
	}
}

- (NSURL *)url
{
return(url);
}

- (void)setUrl:(NSURL *)inUrl
{
if (url != inUrl && [url isEqual:inUrl] == NO)
	{
	[url autorelease];
	url = [inUrl retain];

	if (url)
		{
		NSLog(@"%@", url);

		if ([url isFileURL])
			{
//			[previewer createPreviewImageForUrl:url ofSize:NSMakeSize(128.0f, 128.0f)];
			[[CPreviewManager instance] setUrl:url];
			NSView *thePreview = [[CPreviewManager instance] preview];
			
			NSLog(@"%@", thePreview);
			
			NSEnumerator *theEnumerator = [[previewView subviews] objectEnumerator];
			NSView *theSubview = NULL;
			while ((theSubview = [theEnumerator nextObject]) != NULL)
				{
				[theSubview removeFromSuperview];
				}
			
			[thePreview setAutoresizingMask:[previewView autoresizingMask]];
			[thePreview setFrame:[previewView bounds]];
			
			[previewView addSubview:thePreview];
			
			}
		}
	}
}

- (void)windowDidMove:(NSNotification *)inNotification
{
[self setFocusPoint:[crossHairWindow point]];
}


@end
