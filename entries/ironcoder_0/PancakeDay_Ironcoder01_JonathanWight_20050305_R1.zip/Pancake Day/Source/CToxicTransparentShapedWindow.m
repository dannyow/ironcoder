//
//  CToxicTransparentShapedWindow.m
//  Shelf Life
//
//  Created by Jonathan Wight on 09/13/2004.
//  Copyright 2004 Toxic Software. All rights reserved.
//

#import "CToxicTransparentShapedWindow.h"

@interface CToxicTransparentShapedWindowHelperView : NSView
@end

#pragma mark -

@implementation CToxicTransparentShapedWindow

- (id)initWithContentRect:(NSRect)contentRect styleMask:(unsigned int)aStyle backing:(NSBackingStoreType)bufferingType defer:(BOOL)flag
{
if (self = [super initWithContentRect:contentRect styleMask:NSBorderlessWindowMask backing:bufferingType defer:flag])
	{
	[self setBackgroundColor:[NSColor clearColor]];
	[self setAlphaValue:1.0f];
	[self setOpaque:NO];
	[self setHasShadow:YES];
	}
return(self);
}

- (void)dealloc
{
[super dealloc];
}

- (id)initWithCoder:(NSCoder *)inDecoder
{
if ((self = [super initWithCoder:inDecoder]) != NULL)
	{
	}
return(self);
}

- (void)encodeWithCoder:(NSCoder *)inDecoder
{
[super encodeWithCoder:inDecoder];
}

#pragma mark -

- (void)awakeFromNib
{
NSView *theOldContentView = [[self contentView] retain];
NSView *theNewContentView = [[[[self contentViewDefaultClass] alloc] initWithFrame:[self frame]] autorelease];
[self setContentView:theNewContentView];

NSEnumerator *theEnumerator = [[theOldContentView subviews] objectEnumerator];
NSView *theSubview = NULL;
while ((theSubview = [theEnumerator nextObject]) != NULL)
	{
	[theSubview removeFromSuperviewWithoutNeedingDisplay];
	[theNewContentView addSubview:theSubview];
	}
	
[theOldContentView release];
}

- (BOOL) canBecomeKeyWindow
{
return(YES);
}

#pragma mark -

- (Class)contentViewDefaultClass
{
return([CToxicTransparentShapedWindowHelperView class]);
}

- (void)drawRect:(NSRect)inRect
{
// Nothing to do here. Let sub-classers handle this.
}

@end

#pragma mark -

@implementation CToxicTransparentShapedWindowHelperView

- (BOOL)isOpaque
{
return(NO);
}

- (void)drawRect:(NSRect)inRect
{
[(CToxicTransparentShapedWindow *)[self window] drawRect:inRect];
}

@end
