//
//  CPreviewer.m
//  AXURLTest
//
//  Created by Jonathan Wight on 01/28/2005.
//  Copyright 2005 Toxic Software. All rights reserved.
//

#import "CPreviewer.h"

@implementation CPreviewer

- (void)dealloc
{
//
[super dealloc];
}

#pragma mark -

- (NSView *)previewForURL:(NSURL *)inURL;
{
// Default behavior is to ask the workspace for an icon for the file...
NSImageView *theImageView = [[[NSImageView alloc] initWithFrame:NSMakeRect(0, 0, 256, 256)] autorelease];
NSImage *theImage = [[NSWorkspace sharedWorkspace] iconForFile:[inURL path]];
[theImageView setImage:theImage];
return(theImageView);
}

@end

