//
//  CHTMLPreviewer.m
//  Ironcoder
//
//  Created by Jonathan Wight on 3/5/06.
//  Copyright 2006 Toxic Software. All rights reserved.
//

#import "CHTMLPreviewer.h"

#import <WebKit/WebKit.h>

#import "CPreviewManager.h"

@implementation CHTMLPreviewer

+ (void)initialize
{
[[CPreviewManager instance] registerPreviewer:[[[self alloc] init] autorelease] forType:@"public.html"];
}

- (NSView *)previewForURL:(NSURL *)inURL
{

WebView *theWebView = [[[WebView alloc] initWithFrame:NSMakeRect(0, 0, 256, 256)] autorelease];

[[theWebView mainFrame] loadRequest:[NSURLRequest requestWithURL:inURL]];

return(theWebView);
}


@end
