//
//  CPDFPreviewer.m
//  Ironcoder
//
//  Created by Jonathan Wight on 3/5/06.
//  Copyright 2006 Toxic Software. All rights reserved.
//

#import "CPDFPreviewer.h"

#import <Quartz/Quartz.h>

#import "CPreviewManager.h"

@implementation CPDFPreviewer

+ (void)initialize
{
[[CPreviewManager instance] registerPreviewer:[[[self alloc] init] autorelease] forType:@"com.adobe.pdf"];
}

- (NSView *)previewForURL:(NSURL *)inURL
{
PDFView *thePDFView = [[[PDFView alloc] initWithFrame:NSMakeRect(0, 0, 256, 256)] autorelease];
PDFDocument *theDocument = [[[PDFDocument alloc] initWithURL:inURL] autorelease];
[thePDFView setDocument:theDocument];
return(thePDFView);
}

@end
