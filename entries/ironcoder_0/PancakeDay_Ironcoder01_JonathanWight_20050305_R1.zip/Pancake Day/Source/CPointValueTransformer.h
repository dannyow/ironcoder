//
//  CPointValueTransformer.h
//  Ironcoder
//
//  Created by Jonathan Wight on 03/03/2006.
//  Copyright 2006 Toxic Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface CPointValueTransformer : NSValueTransformer {
}

@end
