//
//  CPointValueTransformer.m
//  Ironcoder
//
//  Created by Jonathan Wight on 03/03/2006.
//  Copyright 2006 Toxic Software. All rights reserved.
//

#import "CPointValueTransformer.h"

@implementation CPointValueTransformer

+ (void)initialize
{
[self setValueTransformer:[[[self alloc] init] autorelease] forName:@"PointValueTransformer"];
}

+ (Class)transformedValueClass
{
return([NSString class]);
}

+ (BOOL)allowsReverseTransformation
{
return(NO);
}

- (id)transformedValue:(id)value
{
return(NSStringFromPoint([value pointValue]));
}

@end
