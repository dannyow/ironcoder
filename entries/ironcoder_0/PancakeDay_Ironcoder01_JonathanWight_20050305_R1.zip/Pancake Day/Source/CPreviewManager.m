//
//  CPreviewManager.m
//  Ironcoder
//
//  Created by Jonathan Wight on 03/04/2006.
//  Copyright 2006 Toxic Software. All rights reserved.
//

#import "CPreviewManager.h"

static CPreviewManager *gInstance = NULL;

@implementation CPreviewManager

+ (CPreviewManager *)instance;
{
return(gInstance);
}

- (id)init
{
if ((self = [super init]) != NULL)
	{
	if (gInstance == NULL)
		gInstance = self;

	previewers = [[NSMutableDictionary alloc] init];
	}
return(self);
}

- (void)dealloc
{
[self setUrl:NULL];
//
[super dealloc];
}

#pragma mark -

- (NSURL *)url
{
return(url); 
}

- (void)setUrl:(NSURL *)inUrl
{
if (url != inUrl)
	{
	[url autorelease];
	url = [inUrl retain];
	}
}

- (NSView *)preview
{
MDItemRef theItemRef = MDItemCreate(kCFAllocatorDefault, (CFStringRef)[[self url] path]);

NSDictionary *theAttributes = (NSDictionary *)MDItemCopyAttributes(theItemRef, MDItemCopyAttributeNames(theItemRef));
[theAttributes retain];
CFRelease(theItemRef);

NSArray *theTypeTree = [theAttributes objectForKey:@"kMDItemContentTypeTree"];

NSLog(@"%@", theTypeTree);			

CPreviewer *thePreviewer = NULL;

NSEnumerator *theEnumerator = [previewers keyEnumerator];
NSString *theType = NULL;
while ((theType = [theEnumerator nextObject]) != NULL)
	{	
	if ([theTypeTree containsObject:theType])
		thePreviewer = [previewers objectForKey:theType];
	}
	
if (thePreviewer == NULL)
	thePreviewer = [[[CPreviewer alloc] init] autorelease];

NSView *thePreview = [thePreviewer previewForURL:[self url]];

//

return(thePreview); 
}

#pragma mark -

- (void)registerPreviewer:(CPreviewer *)inPreviewer forType:(NSString *)inType;
{
[previewers setObject:inPreviewer forKey:inType];
}

@end
