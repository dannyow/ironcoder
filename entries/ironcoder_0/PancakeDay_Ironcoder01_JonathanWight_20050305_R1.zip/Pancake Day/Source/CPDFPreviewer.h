//
//  CPDFPreviewer.h
//  Ironcoder
//
//  Created by Jonathan Wight on 3/5/06.
//  Copyright 2006 Toxic Software. All rights reserved.
//

#import "CPreviewer.h"

@interface CPDFPreviewer : CPreviewer {

}

@end
