//
//  CPreviewManager.h
//  Ironcoder
//
//  Created by Jonathan Wight on 03/04/2006.
//  Copyright 2006 Toxic Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class CPreviewer;

@interface CPreviewManager : NSObject {
	NSURL *url;
	NSMutableDictionary *previewers;
}

+ (CPreviewManager *)instance;

- (NSURL *)url;
- (void)setUrl:(NSURL *)inUrl;

- (NSView *)preview;
- (void)setPreview:(NSView *)preview;

- (void)registerPreviewer:(CPreviewer *)inPreviewer forType:(NSString *)inType;

@end
