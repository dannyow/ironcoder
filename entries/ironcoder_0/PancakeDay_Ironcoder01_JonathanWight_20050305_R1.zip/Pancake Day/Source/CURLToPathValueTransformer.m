//
//  CURLToPathValueTransformer.m
//  
//
//  Created by Jonathan Wight on 02/28/2006.
//  Copyright 2006 Toxic Software. All rights reserved.
//

#import "CURLToPathValueTransformer.h"

@implementation CURLToPathValueTransformer

+ (void)initialize
{
[self setValueTransformer:[[[self alloc] init] autorelease] forName:@"URLToPathValueTransformer"];
}

+ (Class)transformedValueClass
{
return([NSString class]);
}

+ (BOOL)allowsReverseTransformation
{
return(NO); // Because I'm lazy - but I could just write the reverse method in the time it took to write this comment.
}

- (id)transformedValue:(id)value
{
if ([value isFileURL])
	return([[NSFileManager defaultManager] displayNameAtPath:[value path]]);
else
	return(NULL);
}

@end
