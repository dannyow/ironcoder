//
//  CMyController.h
//  AXURLTest
//
//  Created by Jonathan Wight on 01/26/2005.
//  Copyright 2005 Toxic Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <WebKit/WebKit.h>

@class CCrossHairWindow;
@class CMardiGrasWindow;

@interface CMyController : NSObject {
	IBOutlet NSView *previewView;
	IBOutlet CCrossHairWindow *crossHairWindow;
	IBOutlet CMardiGrasWindow *mardiGrasWindow;

	NSPoint focusPoint;
	NSURL *url;
}

- (NSPoint)focusPoint;
- (void)setFocusPoint:(NSPoint)inFocusPoint;

- (void)setUrl:(NSURL *)inUrl;
- (NSURL *)url;

@end
