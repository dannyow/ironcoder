//
//  CImagePreviewer.m
//  Ironcoder
//
//  Created by Jonathan Wight on 03/05/2006.
//  Copyright 2006 Toxic Software. All rights reserved.
//

#import "CImagePreviewer.h"

#import "CPreviewManager.h"

@implementation CImagePreviewer

+ (void)initialize
{
[[CPreviewManager instance] registerPreviewer:[[[self alloc] init] autorelease] forType:@"public.image"];
}

- (NSView *)previewForURL:(NSURL *)inURL
{
NSImageView *theImageView = [[[NSImageView alloc] initWithFrame:NSMakeRect(0, 0, 256, 256)] autorelease];
NSImage *theImage = [[[NSImage alloc] initWithContentsOfURL:inURL] autorelease];
[theImageView setImage:theImage];
return(theImageView);
}

@end
