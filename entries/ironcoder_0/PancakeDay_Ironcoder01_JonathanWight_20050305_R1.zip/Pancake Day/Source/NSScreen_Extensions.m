//
//  NSScreen_Extensions.m
//  AXURLTest
//
//  Created by Jonathan Wight on 3/3/06.
//  Copyright (c) 2006 Toxic Software. All rights reserved.
//

#import "NSScreen_Extensions.h"

@implementation NSScreen (NSScreen_Extensions)

+ (NSScreen *)screenContainingPoint:(NSPoint)inPoint
{
NSEnumerator *theEnumerator = [[self screens] objectEnumerator];
NSScreen *theScreen = NULL;

while ((theScreen = [theEnumerator nextObject]) != NULL)
	{
	if (NSPointInRect(inPoint, [theScreen frame]))
		{
		return(theScreen);
		}
	}
return(NULL);
}

@end
