//
//  FFMinatorGlobal.h
//  FFMinator
//
//  Created by Tom Harrington on 3/4/06;9:16 PM.
//  Copyright 2006 Atomic Bird LLC. All rights reserved.
//

#import <Cocoa/Cocoa.h>


extern NSString *preferencesAppName;
extern NSString *preferencesStatusKey;
extern NSString *preferencesDelayKey;
extern NSString *preferencesShowMeYourBitsKey;

extern NSString *newDelayTimeNotification;
extern NSString *newDelayTimeKey;
extern NSString *newShowMeYourBitsFlagNotification;
extern NSString *newShowMeYourBitsFlagKey;