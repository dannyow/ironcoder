//
//  main.m
//  FFMInatorTool
//
//  Created by Tom Harrington on 03/04/2006;2:59 PM.
//  Copyright Atomic Bird, LLC 2006. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main (int argc, const char * argv[])
{
    return NSApplicationMain(argc, argv);
}
