Readme file located at http://www.evilfork.com/ironcoder0/readme.txt

Author - Colin Barrett