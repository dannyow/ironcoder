//
//  DVController.h
//  DrunkVision
//
//  Created by Colin Barrett on 3/5/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "DVContentView.h"

@interface DVController : NSObject {
	NSPanel	*panel;
	DVContentView	*view;
}

@end
