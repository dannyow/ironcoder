//
//  main.m
//  IronCoder0
//
//  Created by Daniel Jalkut on 3/3/06.
//  Copyright Red Sweater Software 2006. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
