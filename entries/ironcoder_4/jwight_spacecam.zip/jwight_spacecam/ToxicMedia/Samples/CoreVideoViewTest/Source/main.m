//
//  main.m
//  CoreVideoViewTest
//
//  Created by Jonathan Wight on 11/21/2005.
//  Copyright Toxic Software 2005. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
