//
//  main.m
//  SimpleSequenceGrabber
//
//  Created by Jonathan Wight on 10/12/2005.
//  Copyright Toxic Software 2005. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
