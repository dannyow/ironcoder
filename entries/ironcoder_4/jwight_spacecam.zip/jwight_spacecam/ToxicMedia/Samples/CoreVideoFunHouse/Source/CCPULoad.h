//
//  CCPULoad.h
//  CoreVideoFunHouse
//
//  Created by Jonathan Wight on 10/26/2005.
//  Copyright 2005 Toxic Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>

extern float cpuload();
