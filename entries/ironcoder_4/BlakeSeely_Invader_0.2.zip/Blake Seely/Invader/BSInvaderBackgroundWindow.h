//
//  BSInvaderBackgroundWindow.h
//  Invader
//
//  Created by Blake Seely on 10/28/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface BSInvaderBackgroundWindow : NSWindow {

}


@end
