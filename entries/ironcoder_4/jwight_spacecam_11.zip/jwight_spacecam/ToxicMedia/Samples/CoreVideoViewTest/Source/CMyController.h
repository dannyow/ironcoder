//
//  CMyController.h
//  CoreVideoViewTest
//
//  Created by Jonathan Wight on 11/21/2005.
//  Copyright Toxic Software 2005. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#import <ToxicMedia/ToxicMedia.h>

@interface CMyController : NSObject {
	IBOutlet CCoreVideoMovieView *outletMovieView;
}

@end
