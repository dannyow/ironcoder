//
//  CMyController.h
//  SimpleSequenceGrabber
//
//  Created by Jonathan Wight on 10/24/2005.
//  Copyright 2005 Toxic Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface CMyController : NSObject {

}

- (IBAction)actionNewWindow:(id)inSender;

@end
