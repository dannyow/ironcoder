//
//  main.m
//  MotionDetector
//
//  Created by Jonathan Wight on 10/19/2004.
//  Copyright Toxic Software 2004. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
