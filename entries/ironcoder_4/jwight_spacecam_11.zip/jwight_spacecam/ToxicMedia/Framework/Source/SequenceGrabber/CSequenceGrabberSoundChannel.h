//
//  CSequenceGrabberSoundChannel.h
//  SequenceGrabber
//
//  Created by Jonathan Wight on 08/06/2005.
//  Copyright 2005 Toxic Software. All rights reserved.
//

#import "CSequenceGrabberChannel.h"

@class CSequenceGrabber;

@interface CSequenceGrabberSoundChannel : CSequenceGrabberChannel {

}

@end
