//
//  BSInvaderBulletView.h
//  Invader
//
//  Created by Blake Seely on 10/29/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface BSInvaderBulletView : NSView {

}

@end
