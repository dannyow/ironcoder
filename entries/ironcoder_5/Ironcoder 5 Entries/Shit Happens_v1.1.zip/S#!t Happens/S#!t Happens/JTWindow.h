/* JTWindow */

#import <Cocoa/Cocoa.h>

@interface JTWindow : NSWindow
{
}
@end
