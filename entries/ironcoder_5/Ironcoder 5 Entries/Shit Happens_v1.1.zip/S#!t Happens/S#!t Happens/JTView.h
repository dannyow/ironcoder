/* JTView */

#import <Cocoa/Cocoa.h>

@interface JTView : NSView
{
}
@end
