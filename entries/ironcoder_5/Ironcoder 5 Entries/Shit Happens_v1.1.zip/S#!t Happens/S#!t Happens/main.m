//
//  main.m
//  S#!t Happens
//
//  Created by Jim Turner on 4/1/07.
//  Copyright The Des Moines Register 2007. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
