Shit Happens.

No matter how hard you try or how good you are, somedays it just doesn't pay to get out of bed.  Sometimes, random shit just happens.  This is life.  And as a very blonde Geena Davis once said, "Life is pain.  Get used to it."

Authors: 
	Jim Turner (Coder)
	Kristie Turner (Artist)

Contact info:
	myztikjenz@gmail.com

Version 1.1 (2007.04.01)
	- This version makes no changes to the application or code, it just includes information in this file that better honors the rules.  Like, we totally forgot to include an email address to contact us when we win!

Version 1.0 (2007.04.01)
	- Initial release

Instructions for use:
	S#!t Happens is a stand-alone, Intel-friendly app.  A fully compiled version should be sitting in the same folder as this readme.  Double-click and enjoy (it'll become apparent very quickly what the app does).  Command-P will create new ones whenever you like.  To quit, click on the app in the dock and Command-Q.

	It's worth noting that if you happen to have more than one monitor that behavior on anything but the main monitor is "undefined".  Most likely, things just won't line up right or won't show up at all, but I can't guarantee that.

Frameworks:
	ScreenSaver, Cocoa.  I would have used some fancy-pants OpenGL, but I don't know how to do anything like that yet.

License:
	S#!t Happens is licensed under the MIT OpenSource license.  Read the LICENSE.txt file for details.  Seriously, though... do whatever you want to this stuff.  It's all our own work, so you aren't stepping on anyone's toes.

Compiling:
	If you would like to compile the app yourself, there's no special setup required.  Just open the project file and build.  Everything you need should be in there.  The project is set to build a release version by default.