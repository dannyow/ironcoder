//
//  Particle_LifeView.h
//  Particle Life
//
//  Created by Stephan Cleaves on 4/1/07.
//  Copyright (c) 2007, Yellow Camp Software. All rights reserved.
//

#import <ScreenSaver/ScreenSaver.h>

@class YCIC5Simulation;

@interface Particle_LifeView : ScreenSaverView 
{
    YCIC5Simulation *simulation;
}

@end
