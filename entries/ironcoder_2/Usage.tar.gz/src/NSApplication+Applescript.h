//
//  NSApplication+Applescript.h
//  Usage
//
//  Created by Grayson Hansard on 7/22/06.
//  Copyright 2006 From Concentrate Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface NSApplication (Applescript)

-(NSArray *)processes;

@end
