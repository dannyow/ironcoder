Hi!

This is Mark Dalrymple's Iron Coder v2 [CG/Time] entry.

The main entry is "RaceAgainstTime", a silly little game where the goal
is to do something in a shorter time than you did before.  It exercises a lot
of basic CG features.

CGPlay is a demo app that has various CG features implemented in isolation.

notes.vpdoc is a VoodooPad3 document I used during development.  It's in
my subversion, so it's here :-)

Cheers,
++md
