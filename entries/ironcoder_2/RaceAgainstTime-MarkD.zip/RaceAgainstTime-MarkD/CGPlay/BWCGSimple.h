#import "BWCGView.h"

@interface BWCGSimple : BWCGView
{
}


@end // BWCGSimple

