#import "BWCGView.h"

@interface BWCGPatternView : BWCGView
{
    CGImageRef image;
    NSPoint point;
}

@end // BWCGPatternView

