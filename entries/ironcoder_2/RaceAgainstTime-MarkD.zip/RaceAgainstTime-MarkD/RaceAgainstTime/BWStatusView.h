// BWStatusView -- container for the timer views.

#import "BWCGView.h"

@interface BWStatusView : BWCGView
{
}

@end // BWStatusView

