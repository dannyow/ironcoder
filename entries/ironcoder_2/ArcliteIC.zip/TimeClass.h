//
//  TimeClass.h
//  TDWatch App
//
//  Created by Geoff Pado on 7/23/06.
//  Copyright 2006 A Clockwork Apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface TimeClass : NSObject 
{
	IBOutlet NSTextField *timeField;
}

@end
