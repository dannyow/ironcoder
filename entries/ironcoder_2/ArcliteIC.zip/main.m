//
//  main.m
//  TDWatch App
//
//  Created by Geoff Pado on 7/21/06.
//  Copyright A Clockwork Apple 2006. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
