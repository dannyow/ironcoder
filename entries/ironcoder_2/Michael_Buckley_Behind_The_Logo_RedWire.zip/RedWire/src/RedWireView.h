#import <Cocoa/Cocoa.h>
#import "RedWireController.h"

@interface RedWireView : NSView {
    IBOutlet RedWireController* rwc;
}

@end
