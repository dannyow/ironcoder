//
//  main.m
//  Fuzzy Freddy
//
//  Created by Lucas Eckels on 7/21/06.
//  Copyright Flesh Eating Software 2006. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
