//
//  main.m
//  Time Machine
//
//  Created by Daniel Jalkut on 7/21/06.
//  Copyright Red Sweater Software 2006. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
