/*
 *  GraphPatternDrawing.h
 *  WHYDFML
 *
 *  Created by Daniel Jalkut on 7/22/06.
 *  Copyright 2006 Red Sweater Software. All rights reserved.
 *
 */

#include <Carbon/Carbon.h>

void FillRectWithDenimPattern(CGContextRef myContext, CGRect rect);