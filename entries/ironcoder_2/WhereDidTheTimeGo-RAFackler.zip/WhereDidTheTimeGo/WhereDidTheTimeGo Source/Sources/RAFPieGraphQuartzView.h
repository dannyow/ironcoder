//
//  RAFPieGraphQuartzView.h
//  WhereDidTheTimeGo
//
//  Created by Augie Fackler on 7/22/06.
//  Copyright 2006 R. August Fackler. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#define APP_ICON_SIZE 32
#define CALLOUT_LINE_LENGTH 32

CGImageRef CGImageRefFromNSImage(NSImage *image);

@interface RAFPieGraphQuartzView : NSView
{
}
@end
