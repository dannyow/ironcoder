//
//  RAFDesktopWindow.h
//  WhereDidTheTimeGo
//
//  Created by Augie Fackler on 7/22/06.
//  Copyright 2006 R. August Fackler. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface RAFDesktopWindow : NSWindow {

}

@end
