//
//  main.m
//  WhereDidTheTimeGo
//
//  Created by Augie Fackler on 7/22/06.
//  Copyright R. August Fackler 2006. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "RAFTimeAppDelegate.h"

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
